import json
import os

ROOT_DIR = "./lazy"  # 修改为你的 recipe 目录


def convert_shaped(recipe: dict):
    if "key" not in recipe:
        return

    new_key = {}
    for symbol, value in recipe["key"].items():
        if isinstance(value, dict):
            if "item" in value:
                new_key[symbol] = value["item"]
            elif "tag" in value:
                new_key[symbol] = f"#{value['tag']}"
        elif isinstance(value, list):
            new_key[symbol] = value
        else:
            new_key[symbol] = value

    recipe["key"] = new_key


def convert_shapeless(recipe: dict):
    if "ingredients" not in recipe:
        return

    new_ingredients = []
    for ing in recipe["ingredients"]:
        if isinstance(ing, dict):
            if "item" in ing:
                new_ingredients.append(ing["item"])
            elif "tag" in ing:
                new_ingredients.append(f"#{ing['tag']}")
        else:
            new_ingredients.append(ing)

    recipe["ingredients"] = new_ingredients


def process_file(path):
    with open(path, "r", encoding="utf-8") as f:
        try:
            data = json.load(f)
        except json.JSONDecodeError:
            print(f"[跳过] JSON 错误: {path}")
            return

    recipe_type = data.get("type", "")

    if recipe_type == "minecraft:crafting_shaped":
        convert_shaped(data)
    elif recipe_type == "minecraft:crafting_shapeless":
        convert_shapeless(data)
    else:
        return

    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    print(f"[已转换] {path}")


def main():
    for root, _, files in os.walk(ROOT_DIR):
        for file in files:
            if file.endswith(".json"):
                process_file(os.path.join(root, file))


if __name__ == "__main__":
    main()

